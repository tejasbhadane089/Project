package com.prog.hms.service;

import java.util.List;

import com.prog.hms.entity.Treatment;
import com.prog.hms.error.TreatmentNotFoundException;

public interface TreatmentService {

	Treatment addTreatment(Treatment treatment);

	List<Treatment> getallTreatment();

	Treatment findTreatmentById(Integer tid) throws TreatmentNotFoundException;

	Treatment assignTreatmentToPatient(Integer treatid, Integer patid);

	Treatment findByDiseaseName(String treatname) throws TreatmentNotFoundException;

	Treatment updatePaidCost(Integer treatid, Treatment treatment) throws TreatmentNotFoundException;

	

}
