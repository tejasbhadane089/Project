package com.prog.hms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.prog.hms.entity.Treatment;
import com.prog.hms.error.TreatmentNotFoundException;
import com.prog.hms.repository.TreatmentRepository;
import com.prog.hms.service.TreatmentService;

@RestController
public class TreatmentController {

	@Autowired
	private TreatmentService treatmentService;
	@Autowired
	private TreatmentRepository treatmentRepository;
	
	@PostMapping("/addTreatment")
	public Treatment addTreatment(@Valid @RequestBody Treatment treatment) {
		return treatmentService.addTreatment(treatment);
	}
	
	@GetMapping("/findtreatment")
	public List<Treatment> getallTreatment(){
		return treatmentService.getallTreatment();
		
	}
	
	@GetMapping("/findbytreatid/{tid}")
	public Treatment findTreatmentById(@PathVariable ("tid") Integer tid) throws TreatmentNotFoundException {
		return treatmentService.findTreatmentById(tid);
	}
	
	@PutMapping("/treatment/{treatid}/patient/{patid}")
	public Treatment assignTreatmentToPatient(@PathVariable ("treatid") Integer treatid,@PathVariable("patid") Integer patid) {
		return treatmentService.assignTreatmentToPatient(treatid,patid);
		
	}
	
	@GetMapping("/findtreatbyname/{treatname}")
	public Treatment findByDiseaseName(@PathVariable ("treatname") String treatname) throws TreatmentNotFoundException {
		return treatmentService.findByDiseaseName(treatname);
	}
	
	
	
	
	/*@PutMapping("/updatecost/{treatid}")
	public Treatment updatePaidCost(@PathVariable ("treatid") Integer treatid,@RequestBody Treatment treatment) throws TreatmentNotFoundException {
		
		return treatmentService.updatePaidCost(treatid,treatment);
	}*/
	
	@GetMapping("/cost/{treid}/treatment/{tid}")
	public String treatmentCostGet(@PathVariable ("treid") Integer treid,@PathVariable ("tid") Integer tid) {
		float treatcost= treatmentRepository.findTreatmentById(treid)-treatmentRepository.findCostById(tid);
		return "Remaining Payment you have to pay = "+treatcost;
	}
	
	
	
	
}
