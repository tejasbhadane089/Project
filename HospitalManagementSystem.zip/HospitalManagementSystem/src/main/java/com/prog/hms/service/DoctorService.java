package com.prog.hms.service;

import java.util.List;
import java.util.Optional;

import com.prog.hms.entity.Doctor;
import com.prog.hms.error.DoctorNotFoundException;

public interface DoctorService {

	Doctor addDoctor(Doctor doctor);

	List<Doctor> getAllDoctors();

	Doctor findDoctorById(Integer docid) throws DoctorNotFoundException;

	Doctor findDoctorName(String docname);

	void deleteDoctor(Integer doctorid) throws DoctorNotFoundException;

	Doctor updateDoctorRecord(Integer docid, Doctor doctor) throws DoctorNotFoundException;

	

}
