package com.prog.hms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.prog.hms.entity.Patient;
import com.prog.hms.error.PatientNotFoundException;
import com.prog.hms.service.PatientService;

@RestController
public class PatientController {
	
	@Autowired
	private PatientService patientService;

	@PostMapping("/addPatient")
	public Patient addPatient(@Valid @RequestBody Patient patient) {
		return patientService.addPatient(patient);
		
	}
	
	@GetMapping("/getpatient")
	public List<Patient> getAllPatients(){
		return patientService.getAllPatients();
		}

	@GetMapping("/findpatientById/{pid}")
		public Patient findPatientById(@PathVariable ("pid") Integer pid) throws PatientNotFoundException {
		return patientService.findPatientById(pid);
	}
	
	@PutMapping("/patient/{pid}/doctor/{did}")
	public Patient assignPatientToDoctor(@PathVariable ("pid") Integer pid, @PathVariable ("did") Integer did) {
		return patientService.assignPatientToDoctor(pid,did);
	}
	
	@GetMapping("/findpatbyname/{patname}")
	public Patient findPatientByName(@PathVariable ("patname") String patname) throws PatientNotFoundException {
		return patientService.findPatientByName(patname);
	}
	
	@DeleteMapping("deletepatient/{patientid}")
	public String deletePatientById(@PathVariable ("patientid") Integer patid,@RequestBody Patient patient) throws PatientNotFoundException {
		patientService.deletePatientById(patid,patient);
		return "Record Deleted Successfully";
	}
	
	@PutMapping("/updatepatient/{patid}")
	public Patient updatePatientById(@PathVariable ("patid") Integer patid,@RequestBody Patient patient) throws PatientNotFoundException {
		return patientService.updatePatientById(patid,patient);
	}
	
}
