package com.prog.hms.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Patient {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer patientId;
	@NotEmpty
	@Size(min=3,max=40,message="Name should be of min 3 char and max 40 char")
	private String patientName;
	@NotEmpty(message="Phone number is required.")
	private String patientPhone;
	@Min(18)
	@Max(100)
	private int patientAge;
	@NotEmpty(message="Address is required.")
	private String patientAddresss;
	
	//////////////////////////////////////inside patient class add doctor
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="doctor_Id", referencedColumnName = "doctorId")
	
	
	
	
	private Doctor doctor;
	
	
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	
	///////////////////////////////////////////////
	
	
	
	
	/////////****adding patient to treatment/******///////////
	@JsonIgnore
	@OneToMany(mappedBy="patient")
	private Set<Treatment> treatment = new HashSet<>();
	
	public Set<Treatment> getTreatment() {
		return treatment;
	}
	public void setTreatment(Set<Treatment> treatment) {
		this.treatment = treatment;
	}
	
	/////////***********//////////////
	
	
	
	public Integer getPatientId() {
		return patientId;
	}
	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientPhone() {
		return patientPhone;
	}
	public void setPatientPhone(String patientPhone) {
		this.patientPhone = patientPhone;
	}
	public String getPatientAddresss() {
		return patientAddresss;
	}
	public void setPatientAddresss(String patientAddresss) {
		this.patientAddresss = patientAddresss;
	}
	public int getPatientAge() {
		return patientAge;
	}
	public void setPatientAge(int patientAge) {
		this.patientAge = patientAge;
	}
	public void assignDoctor(Doctor doctor2) {
		this.doctor=doctor2;
		
	}
	
	
	
	
}
