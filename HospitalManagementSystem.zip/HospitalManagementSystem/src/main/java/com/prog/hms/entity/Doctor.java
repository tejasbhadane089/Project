package com.prog.hms.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Doctor {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer doctorId;
	@NotEmpty
	@Size(min=3,max=40,message="Name should be minimum 3 and maximum 40 char")
	private String doctorName;
	@NotEmpty(message="Phone number can not be empty")
	private String doctorPhone;
	@NotEmpty(message="Department can not be empty")
	private String doctorDepartment;
	@NotEmpty(message="Degree can't be empty")
	private String doctorDegree;
	@NotEmpty(message="College is required!")
	private String doctorCollege;
	
	
	//////////////////////////
	@JsonIgnore
	@OneToMany(mappedBy = "doctor")
	private Set<Patient> patient = new HashSet<>();
	
	public Set<Patient> getPatient() {
		return patient;
	}
	public void setPatient(Set<Patient> patient) {
		this.patient = patient;
	}
	
	//////////////////////////
	
	
	
	public Integer getDoctorId() {
		return doctorId;
	}
	
	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getDoctorPhone() {
		return doctorPhone;
	}
	public void setDoctorPhone(String doctorPhone) {
		this.doctorPhone = doctorPhone;
	}
	public String getDoctorDepartment() {
		return doctorDepartment;
	}
	public void setDoctorDepartment(String doctorDepartment) {
		this.doctorDepartment = doctorDepartment;
	}
	public String getDoctorDegree() {
		return doctorDegree;
	}
	public void setDoctorDegree(String doctorDegree) {
		this.doctorDegree = doctorDegree;
	}
	public String getDoctorCollege() {
		return doctorCollege;
	}
	public void setDoctorCollege(String doctorCollege) {
		this.doctorCollege = doctorCollege;
	}
	
	
	

}
