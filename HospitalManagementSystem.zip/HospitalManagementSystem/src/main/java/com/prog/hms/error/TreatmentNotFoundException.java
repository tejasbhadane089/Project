package com.prog.hms.error;

public class TreatmentNotFoundException extends Exception{

	public TreatmentNotFoundException(String message) {
		super(message);
	}

	
	
}
