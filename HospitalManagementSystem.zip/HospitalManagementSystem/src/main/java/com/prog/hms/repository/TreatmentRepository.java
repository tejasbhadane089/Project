package com.prog.hms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.prog.hms.entity.Treatment;

@Repository
public interface TreatmentRepository extends JpaRepository<Treatment, Integer>{

	Optional<Treatment> findByPatientDisease(String treatname);

	//Treatment findTreatmentById(Integer treatid);

	@Query("select sum(m.treatment_Cost) from treatment m where treatment_Id = :id")
	float findTreatmentById(@Param ("id") Integer tid);
	
	@Query("select sum(m.cost_Paid) from treatment m where treatment_Id = :id")
	float findCostById(@Param ("tid") Integer treid);

}
