package com.prog.hms.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotEmpty;

@Entity
public class Treatment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer treatmentId;
	@NotEmpty(message="Disease Type is required.")
	private String patientDisease;
	
	private float treatmentCost;
	
	private float costPaid;
	private float pendingCost;
	
	private String admitDate;
	private String dischargeDate;
	
	//////////////////////////////////
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="patient_Id", referencedColumnName = "patientId")
	
	private Patient patient;
	
	
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	
	/////////////////////////////////
	public float getPendingCost() {
		return pendingCost;
	}
	public void setPendingCost(float pendingCost) {
		this.pendingCost = pendingCost;
	}
	
	
	public Integer getTreatmentId() {
		return treatmentId;
	}
	public void setTreatmentId(Integer treatmentId) {
		this.treatmentId = treatmentId;
	}
	public String getPatientDisease() {
		return patientDisease;
	}
	public void setPatientDisease(String patientDisease) {
		this.patientDisease = patientDisease;
	}
	
	public String getAdmitDate() {
		return admitDate;
	}
	public void setAdmitDate(String admitDate) {
		this.admitDate = admitDate;
	}
	public String getDischargeDate() {
		return dischargeDate;
	}
	public void setDischargeDate(String dischargeDate) {
		this.dischargeDate = dischargeDate;
	}
	public float getTreatmentCost() {
		return treatmentCost;
	}
	public void setTreatmentCost(float treatmentCost) {
		this.treatmentCost = treatmentCost;
	}
	public float getCostPaid() {
		return costPaid;
	}
	public void setCostPaid(float costPaid) {
		this.costPaid = costPaid;
	}
	public void assignPatient(Patient patient2) {
		this.patient = patient2;
		
	}
	
	
	
}
