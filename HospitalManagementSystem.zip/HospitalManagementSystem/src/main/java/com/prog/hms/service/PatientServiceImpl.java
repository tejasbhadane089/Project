package com.prog.hms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prog.hms.entity.Doctor;
import com.prog.hms.entity.Patient;
import com.prog.hms.error.PatientNotFoundException;
import com.prog.hms.repository.DoctorRepository;
import com.prog.hms.repository.PatientRepository;

@Service
public class PatientServiceImpl implements PatientService{

	@Autowired
	private PatientRepository  patientRepository;
	@Autowired
	private DoctorRepository doctorRepository;

	@Override
	public Patient addPatient(Patient patient) {
		
		return patientRepository.save(patient);
	}

	@Override
	public List<Patient> getAllPatients() {
		
		return patientRepository.findAll();
	}

	@Override
	public Patient assignPatientToDoctor(Integer pid, Integer did) {
		Patient patient = patientRepository.findById(pid).get();
		Doctor doctor = doctorRepository.findById(did).get();
		patient.assignDoctor(doctor);
		return patientRepository.save(patient);
	}

	@Override
	public Patient findPatientById(Integer pid) throws PatientNotFoundException {
		Optional<Patient> patient = patientRepository.findById(pid);
		if(!patient.isPresent())
			throw new PatientNotFoundException("Patient Id not found.");
		return patient.get();
	}

	@Override
	public Patient findPatientByName(String patname) throws PatientNotFoundException {
		Optional<Patient> patient = patientRepository.findByPatientName(patname);
		if(patient==null)
			throw new PatientNotFoundException("Patient Name Not Found!!");
		return patient.get();
	}

	@Override
	public void deletePatientById(Integer patid, Patient patient) throws PatientNotFoundException {
		Optional<Patient> patient1 = patientRepository.findById(patid);
		if(!patient1.isPresent())
			throw new PatientNotFoundException("Patient Id Not Found");
		doctorRepository.deleteById(patid);
		
	}

	@Override
	public Patient updatePatientById(Integer patid, Patient patient) throws PatientNotFoundException {
		Optional<Patient> patient2 = patientRepository.findById(patid);
		if(!patient2.isPresent())
			throw new PatientNotFoundException("Patient Id Not Found");
		else {
			Patient pot = patientRepository.findById(patid).get();
			if(patient.getPatientName()!=null)
				pot.setPatientName(patient.getPatientName());
			if(patient.getPatientAddresss()!=null)
				pot.setPatientAddresss(patient.getPatientAddresss());
			if(patient.getPatientPhone()!=null)
				pot.setPatientPhone(patient.getPatientPhone());
			return patientRepository.save(pot);
		}
		
		
	}

	
	

}
