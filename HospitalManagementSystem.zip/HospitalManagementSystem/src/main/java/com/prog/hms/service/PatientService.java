package com.prog.hms.service;

import java.util.List;

import com.prog.hms.entity.Patient;
import com.prog.hms.error.PatientNotFoundException;

public interface PatientService {

	Patient addPatient(Patient patient);

	List<Patient> getAllPatients();

	Patient assignPatientToDoctor(Integer pid, Integer did);

	Patient findPatientById(Integer pid) throws PatientNotFoundException;

	Patient findPatientByName(String patname) throws PatientNotFoundException;

	void deletePatientById(Integer patid, Patient patient) throws PatientNotFoundException;

	Patient updatePatientById(Integer patid, Patient patient) throws PatientNotFoundException;

	

}
