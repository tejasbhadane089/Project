package com.prog.hms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.prog.hms.entity.Doctor;
import com.prog.hms.error.DoctorNotFoundException;
import com.prog.hms.service.DoctorService;

@RestController
public class DoctorController {
	
	@Autowired
	private DoctorService doctorService;
	
	@PostMapping("/addDoctor")
	public Doctor addDoctor(@Valid @RequestBody Doctor doctor) {
		return doctorService.addDoctor(doctor);
		
	}
	
	@GetMapping("/getalldata")
	public List<Doctor> getAllDoctors(){
		return doctorService.getAllDoctors();
		
		
	}

	@GetMapping("/finddocbyid/{docid}")
	public Doctor findDoctorById(@PathVariable ("docid") Integer docid) throws DoctorNotFoundException {
		return doctorService.findDoctorById(docid);
		
	}
	
	@GetMapping("/finddocbyname/{docname}")
		public Doctor findDoctorName(@PathVariable ("docname") String docname){
			return doctorService.findDoctorName(docname);
		
		
		}
	
	@DeleteMapping("/deletedoctor/{doctorid}")
	public String deleteDoctor(@PathVariable ("doctorid") Integer doctorid) throws DoctorNotFoundException {
		 doctorService.deleteDoctor(doctorid);
		 return "Doctor record deleted Successfully";
	}
	
	@PutMapping("/updatedoctor/{docid}")
	public Doctor updateDoctorRecord(@PathVariable ("docid") Integer docid,@RequestBody Doctor doctor) throws DoctorNotFoundException {
		return doctorService.updateDoctorRecord(docid,doctor);
	}
	
	
}
