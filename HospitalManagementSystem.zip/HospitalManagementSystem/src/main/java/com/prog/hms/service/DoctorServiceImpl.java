package com.prog.hms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prog.hms.entity.Doctor;
import com.prog.hms.error.DoctorNotFoundException;
import com.prog.hms.repository.DoctorRepository;

@Service
public class DoctorServiceImpl implements DoctorService{

	@Autowired
	private DoctorRepository doctorRepository;

	@Override
	public Doctor addDoctor(Doctor doctor) {
		
		return doctorRepository.save(doctor);
	}

	@Override
	public List<Doctor> getAllDoctors() {
		
		return doctorRepository.findAll();
	}

	@Override
	public Doctor findDoctorById(Integer docid) throws DoctorNotFoundException {
		
		Optional<Doctor> doctor = doctorRepository.findById(docid);
		if(!doctor.isPresent())
			throw new DoctorNotFoundException("Doctor Id not found");
		
		
		return doctor.get();
	
	}

	@Override
	public Doctor findDoctorName(String docname) {
		
		return doctorRepository.findByDoctorName(docname);
	}

	@Override
	public void deleteDoctor(Integer doctorid) throws DoctorNotFoundException {
		Optional<Doctor> doctor = doctorRepository.findById(doctorid);
		
		if(!doctor.isPresent())
			throw new DoctorNotFoundException("Doctor Id not found");
		doctorRepository.deleteById(doctorid);
		
	}

	@Override
	public Doctor updateDoctorRecord(Integer docid, Doctor doctor) throws DoctorNotFoundException {
		Optional<Doctor> doctor1 = doctorRepository.findById(docid);
		if(!doctor1.isPresent())
			throw new DoctorNotFoundException("Id not found");
		else {
			Doctor doc=doctorRepository.findById(docid).get();
			if(doctor.getDoctorName()!=null)
			doc.setDoctorName(doctor.getDoctorName());
			if(doctor.getDoctorPhone()!=null)
				doc.setDoctorPhone(doctor.getDoctorPhone());
			if(doctor.getDoctorDegree()!=null)
				doc.setDoctorDegree(doctor.getDoctorDegree());
			if(doctor.getDoctorCollege()!=null)
				doc.setDoctorCollege(doctor.getDoctorCollege());
			return doctorRepository.save(doc);
			
		}
		
	}

	
	
	
	
}
