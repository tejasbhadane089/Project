package com.prog.hms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prog.hms.entity.Patient;
import com.prog.hms.entity.Treatment;
import com.prog.hms.error.TreatmentNotFoundException;
import com.prog.hms.repository.PatientRepository;
import com.prog.hms.repository.TreatmentRepository;

@Service
public class TreatmentServiceImpl implements TreatmentService{

	@Autowired
	private TreatmentRepository treatmentRepository;
	
	@Autowired
	private PatientRepository patientRepository;

	@Override
	public Treatment addTreatment(Treatment treatment) {
		
		return treatmentRepository.save(treatment);
	}

	@Override
	public List<Treatment> getallTreatment() {
		
		return treatmentRepository.findAll();
	}

	@Override
	public Treatment findTreatmentById(Integer tid) throws TreatmentNotFoundException {
		Optional<Treatment> treatment = treatmentRepository.findById(tid);
		if(!treatment.isPresent())
			throw new TreatmentNotFoundException("Treatment Id Not Found");
		return treatment.get();
	}

	@Override
	public Treatment assignTreatmentToPatient(Integer treatid, Integer patid) {
		Treatment treatment = treatmentRepository.findById(treatid).get();
		Patient patient = patientRepository.findById(patid).get();
		treatment.assignPatient(patient);
		return treatmentRepository.save(treatment);
	}

	@Override
	public Treatment findByDiseaseName(String treatname) throws TreatmentNotFoundException {
	    Optional<Treatment> treatment = treatmentRepository.findByPatientDisease(treatname);
	    if(!treatment.isPresent())
	    	throw new TreatmentNotFoundException(treatname);
		return treatment.get();
	}

	@Override
	public Treatment updatePaidCost(Integer treatid, Treatment treatment) throws TreatmentNotFoundException {
		Treatment treat = treatmentRepository.findById(treatid).get();
		if(treat==null)
			throw new TreatmentNotFoundException("Treatment Id not found");
		else {
			if(treatment.getCostPaid()!=0) {
				float cost=treat.getCostPaid();
				cost=cost-treatment.getCostPaid();
				treat.setCostPaid(cost);
			
			}
		}
		
		return treatmentRepository.save(treat);
		
	}

	
	
}
