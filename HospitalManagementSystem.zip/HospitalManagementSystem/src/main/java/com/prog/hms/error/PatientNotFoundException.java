package com.prog.hms.error;

public class PatientNotFoundException extends Exception{

	
	public PatientNotFoundException(String message) {
		
		super(message);
	}

}
